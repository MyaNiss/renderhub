import React from 'react';
import {useState} from "react";
import style from '../assets/css/header.module.css'
import ProfileDropdown from "./ProfileDropdown.jsx";
import {useAuthStore} from "../store/authStore.jsx";
import useSearch from "../customHook/useSearch.jsx";

const Header = () => {

    const logout = useAuthStore((state) => state.logout);
    const isAuthenticated = true; // useAuthStore((state) => state.isAuthenticated());
    const userName = "닉네임"; //useAuthStore((state) => state.userName);

    const {searchTerm, setSearchTerm, handleSearch} = useSearch();

    const executeSearch = () => {
        handleSearch(searchTerm);
    }

    return (
        <div className={style.header}>
            <div className={style.leftSection}>
                <div className={style.logo}>
                    <a href="/">로고</a>
                </div>

                <nav className={style.nav}>
                    <a href="/post" className={style.menuItem}>탐색</a>
                    <a href="/board" className={style.menuItem}>게시판</a>
                </nav>
            </div>

            <div className={style.searchContainer}>
                <input
                    type="text"
                    placeholder="검색어를 입력하세요"
                    className={style.searchInput}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyDown={(e) => {if (e.key === 'Enter') {executeSearch()}}}
                />
                <button className={style.searchButton} onClick={executeSearch}>
                    Q
                </button>
            </div>

            <div className={style.authContainer}>
                {isAuthenticated ? (
                    <ProfileDropdown
                        username={userName}
                        onLogout={logout}
                    />
                ) : (
                    <>
                        <a href="/login" className={style.authButton}>로그인</a>
                        <a href="/register" className={`${style.authButton} ${style.registerButton}`}>회원가입</a>
                    </>
                )}
            </div>
        </div>
    );
};

export default Header;