import {createBrowserRouter} from "react-router";
import Layout from "../pages/Layout.jsx";
import BoardList from "../pages/board/BoardList.jsx";
import HomePage from "../pages/HomePage.jsx";
import BoardWrite from "../pages/board/BoardWrite.jsx";
import BoardDetail from "../pages/board/BoardDetail.jsx";
import BoardUpdate from "../pages/board/BoardUpdate.jsx";

export const router = createBrowserRouter(
    [
        {
            path: '/',
            element: <Layout />,
            children: [
                {
                    index: true,
                    element: <HomePage />,
                },
                {
                    path: '/board',
                    children: [
                        {
                            index: true,
                            element: <BoardList />,
                        },
                        {
                            path: 'write',
                            element: <BoardWrite/>
                        },
                        {
                            path: 'detail/:id',
                            element: <BoardDetail/>
                        },
                        {
                            path: 'update/:id',
                            element: <BoardUpdate/>
                        }
                    ]
                }
            ]
        }
    ]
)