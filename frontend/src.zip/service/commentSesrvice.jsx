import api from "../api/apiClient.jsx";


export const commentAPI = {
    getCommentList: async (boardId, currentPage = 0, pagePerRows = 5) => {
        if(!boardId){
            throw new Error("게시글 ID가 필요합니다");
        }

        const res = await api.get(`/api/v1/board/${boardId}/comments`,{
            params: {
                currentPage: currentPage,
                pagePerRows: pagePerRows
            }
        });

        return res.data;
    },

    writeComment: async ({boardId, formData}) => {
        if (!boardId) {
            throw new Error("게시글 ID가 필요합니다");
        }

        const res = await api.post(`/api/v1/board/${boardId}/comments`, formData);

        return res.data;
    },

    deleteComment: async (commentId) => {
        const res = await api.delete(`/api/v1/board/${commentId}`);
        return res.data;
    }
}