import {useMutation, useQuery, useQueryClient} from "@tanstack/react-query";
import {commentAPI} from "../service/commentSesrvice.jsx";


export const useGetCommentList = (boardId, currentPage, pagePerRows) => {
    return useQuery({
        queryKey: ['comments', boardId, currentPage, pagePerRows],
        queryFn: () => commentAPI.getCommentList(boardId, currentPage, pagePerRows),
    });
};

export const useComment = () => {
    const queryClient = useQueryClient();

    const writeCommentMutation = useMutation({
        mutationFn: ({boardId, formData}) => commentAPI.writeComment({boardId, formData}),
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({queryKey: ['comments', variables.boardId]});

            console.log('댓글 작성 성공', data);
        }
    });

    const deleteCommentMutation = useMutation({
        mutationFn: (commentId) => commentAPI.deleteComment(commentId),
        onSuccess: () => {
            console.log("댓글 삭제 성공");
        }
    });

    return {writeCommentMutation, deleteCommentMutation};
}