import React, {useCallback, useEffect} from 'react';
import * as yup from "yup";
import {useNavigate, useParams} from "react-router";
import {useBoard, useGetBoardDetail} from "../../customHook/useBoard.jsx";
import {yupResolver} from "@hookform/resolvers/yup";
import useQuillEditor from "../../customHook/useQuillEditor.jsx";
import style from "../../assets/css/board.common.module.css";

const schema = yup.object().shape({
    title : yup.string().required('제목을 입력하십시오'),
    contents : yup.string().required('내용을 입력하십시오')
})
const BoardUpdate = () => {
    const navigate = useNavigate();
    const {id} = useParams();

    const { updateBoardMutation } = useBoard();

    const {
        data : initailData
    } = useGetBoardDetail(id);

    const {register, handleSubmit, formState: {errors}, setValue, watch, reset} = userForm({
        resolver: yupResolver(schema),
        defaultValue: {
            title: "",
            contents: ""
        }
    });

    useEffect(() => {
        if (initailData) {
            reset({
                title: initailData.title,
                contents: initailData.contents
            });
        }
    }, [initailData, reset]);

    const quillValue = watch('contents');

    const handleQuillChange = useCallback((value) => {
        setValue("contents", value, {shouldValidate: true});
    }, [setValue]);

    const QuillEditorComponent = useQuillEditor(quillValue, handleQuillChange);

    const onSubmit = async (data) => {
        console.log("게시글 수정 데이터", data);

        const formData = new FormData();
        formData.append("id", id);
        formData.append("title", data.title);
        formData.append("contents", data.contents);

        try{
            const result = await updateBoardMutation.mutateAsync(formData);

            if(result.resultCode === 200){
                alert("게시글이 수정되었습니다");
                navigate(`/board/update/${id}`);
            } else {
                alert("게시글 수정에 실패했습니다");
                return false;
            }
        } catch (error) {
            console.error(error);
            alert(error.message);
        }
    }

    const { ref : titleRef, ...restTitleProps} = register('title');

    const moveToList = () => {
        if(window.confirm("수정을 취소하고 상세 페이지로 돌아가시겠습니까?")){
            navigate(`/board/detail/${id}`);
        }
    }

    return (
        <div className={style.container}>
            <header className={style.header}>
                게시글 수정
            </header>
            <section className={style.section}>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <div className={style.formGroup}>
                        <label htmlFor="title">제목</label>
                        <input
                            type="text"
                            id="title"
                            className={style.formInput}
                            placeholder="제목을 입력하십시오"
                            ref={titleRef}
                            {...restTitleProps}
                        />
                        {errors.title && <p className={style.errorMessage}>{errors.title.message}</p>}
                    </div>

                    <div className={style.formGroup}>
                        <label htmlFor="contents">내용</label>
                        <div className={"quill-wrapper"}>
                            {QuillEditorComponent}
                        </div>
                        <div>
                            {errors.contents && <p className={style.errorMessage}>{errors.contents.message}</p>}
                        </div>
                    </div>

                    <div className={`${style.buttonGroup}`}>
                        <button
                            type="button"
                            className={`${style.button} ${style.buttonAll}`}
                            onClick={moveToList}
                        >
                            취소
                        </button>
                        <button
                            type="submit"
                            className={`${style.button} ${style.buttonPrimary}`}
                        >
                            수정
                        </button>
                    </div>
                </form>
            </section>
        </div>
    );
};

export default BoardUpdate;